<?php
$conn = new mysqli('localhost','root','','web')
or die ("Can't connect!");
session_start();
?>