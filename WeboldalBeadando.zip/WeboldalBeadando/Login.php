<?php
require("connect.php");
require("functions.php");
    $username = $_POST["username"];
    $password = $_POST["password"];
    if(Exists($username,$password,$conn))
    {
        header("Location:index.php");

    }
    else
    {
        echo"baszotgeic";
        echo "<form action='index.php'>";
        echo "<input type='submit' value='Back'>";
        echo "</form>";
    }
    $conn->close();
?>